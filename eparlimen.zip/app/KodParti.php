<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class KodParti extends Model
{
    protected $table = "kod_parti";

    protected $guarded = [];
}
