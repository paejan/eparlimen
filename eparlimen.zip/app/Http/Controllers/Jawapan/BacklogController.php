<?php

namespace App\Http\Controllers\Jawapan;

use App\AhliParlimen;
use App\Bahagian;
use App\Http\Controllers\Controller;
use App\KodKategori;
use App\KodKategoriSub;
use App\KodPertanyaan;
use App\KodSidang;
use App\SoalanParlimen;
use App\TableMenuUser;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class BacklogController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index(Request $request)
    {
        $usermenu = TableMenuUser::where('menu_id',1)->where('id_kakitangan', Auth::user()->id_kakitangan)->first();

        // dd($usermenu);

        $tanya = KodPertanyaan::get();

        $kategori = KodKategori::where('status',0)->orderBy('kod_kategori')->get();

        $sub = KodKategoriSub::where('status',0)->get();
        // dd($sub);
        $bahagian = Bahagian::where('status',0)->get();

        return view('jawapan/backlog/index', compact('usermenu','tanya','kategori','sub','bahagian'));
    }
    
    public function search(Request $request)
    {
        // dd($request->all());
        
        if($request->l_type == '1'){
            $sidang = KodSidang::where('status',0)->where('j_dewan',1)->orderBy('tahun','DESC')->orderBy('start_dt','DESC')->get();
    
            $ahli = AhliParlimen::join('kod_parlimen','ahliparlimen.kod_kaw_ap','kod_parlimen.p_kod')->where('type','AP')->get();
        } else if($request->l_type == '2'){
            $sidang = KodSidang::where('status',0)->where('j_dewan',2)->orderBy('tahun','DESC')->orderBy('start_dt','DESC')->get();
    
            $ahli = AhliParlimen::where('type','AD')->get();
        }
        // dd($ahli);
        return response()->json([$sidang,$ahli]);

    }

    public function store(Request $request)
    {
        // dd($request->all());
        
        $user = Auth::user()->id_kakitangan;

        $soalan_id = date('Ymd')."-".uniqid();

        $soalan = new SoalanParlimen();
        $soalan->soalan_id = $soalan_id;
        $soalan->type_soalan = $request->status;
        $soalan->tkh_soalan = $request->tkh_soalan;
        $soalan->no_soalan = $request->no_soalan;
        $soalan->j_tanya = $request->j_tanya;
        $soalan->j_tanya_det = $request->j_tanya_det;
        $soalan->j_dewan = $request->l_type;
        $soalan->id_sidang = $request->id_sidang;
        $soalan->s_oleh = $request->nama_ap;
        $soalan->j_kategori = $request->j_kategori;
        $soalan->soalan = $request->soal;
        $soalan->soalan_oleh = $request->ahli_parlimen;
        $soalan->soalan_kawasan = $request->kawasan_parlimen;
        $soalan->tkh_jwb_parlimen = $request->tkh_jwb_parlimen;
        $soalan->menteri = $request->menteri;
        $soalan->create_dt = now();
        $soalan->create_by = $user;
        $soalan->update_dt = now();
        $soalan->update_by = $user;
        $soalan->is_deleted = 0;

        $soalan->save();

        return response()->json('OK');
    }
}
